# Rocky Linux 9 Docker Target

This directory contains the Rocky Linux 9 Docker implementation for Zimbra 10.1 Network Edition.

## Tested Version

```text
Release 10.1.19.GA.4688.RHEL9_64.20240911074203 NETWORK edition.
```

## Files

```text
docker/
├── Dockerfile
├── Makefile
├── docker-compose.yml
└── opt/
    └── start.sh
```

## Build

```bash
cd docker-zimbra-rocky9/docker

docker build --rm -t docker-zimbra-10_1-rocky9-dwinar:latest .
```

## Run

```bash
docker rm -f zimbra-rocky9 2>/dev/null || true

docker run -d --name zimbra-rocky9 \
  --hostname zimbra10.dwinar.web.id \
  --dns 8.8.8.8 --dns 1.1.1.1 \
  --privileged \
  -e PASSWORD='ChangeMe123!' \
  -e TIMEZONE='Asia/Jakarta' \
  -e DNS_FORWARDER_1='8.8.8.8' \
  -e DNS_FORWARDER_2='1.1.1.1' \
  -p 25:25 -p 80:80 -p 443:443 -p 465:465 -p 587:587 \
  -p 110:110 -p 143:143 -p 993:993 -p 995:995 \
  -p 7071:7071 -p 9071:9071 \
  docker-zimbra-10_1-rocky9-dwinar:latest
```

## Verify

```bash
docker logs -f zimbra-rocky9

docker exec -it zimbra-rocky9 bash
su - zimbra
zmcontrol status
zmcontrol -v
```

## Notes

- The first run performs the actual Zimbra install.
- `start.sh` configures local BIND DNS, `/etc/hosts`, `/etc/resolv.conf`, answer file, and Zimbra config file.
- Do not use `Ctrl+C` on foreground containers unless you want to stop the container. Use `Ctrl+P` then `Ctrl+Q` to detach safely.
- This Docker target is for lab/testing, not production.
